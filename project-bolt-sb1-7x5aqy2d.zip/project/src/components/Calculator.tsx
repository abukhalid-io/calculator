import React, { useState } from 'react';
import { Calculator as CalcIcon, Settings, Zap, TrendingUp, BarChart3 } from 'lucide-react';

interface CalculationInputs {
  lrv: number;
  urv: number;
  unit: string;
  zero: number;
  span: number;
  signalUnit: string;
}

interface FlowrateInputs {
  min: number;
  max: number;
  frunit: string;
}

const Calculator: React.FC = () => {
  const [inputs, setInputs] = useState<CalculationInputs>({
    lrv: 0,
    urv: 100,
    unit: 'bar',
    zero: 4,
    span: 20,
    signalUnit: 'mA'
  });

  const [flowrateInputs, setFlowrateInputs] = useState<FlowrateInputs>({
    min: 0,
    max: 1000,
    frunit: 'L/min'
  });

  const [activeTab, setActiveTab] = useState('scale');
  const [results, setResults] = useState<any[]>([]);
  const [singleResult, setSingleResult] = useState<any>(null);

  const calculateScaleValues = () => {
    const percentages = [0, 25, 50, 75, 100];
    const newResults = percentages.map(percentage => {
      const calculatedValue = inputs.lrv + (percentage / 100) * (inputs.urv - inputs.lrv);
      const signalValue = inputs.zero + (percentage / 100) * (inputs.span - inputs.zero);
      return {
        percentage,
        value: calculatedValue.toFixed(2),
        unit: inputs.unit,
        signalValue: signalValue.toFixed(2),
        signalUnit: inputs.signalUnit
      };
    });
    setResults(newResults);
  };

  const calculateFromSignal = (signalValue: number) => {
    const percentage = ((signalValue - inputs.zero) / (inputs.span - inputs.zero)) * 100;
    const value = ((signalValue - inputs.zero) / (inputs.span - inputs.zero)) * (inputs.urv - inputs.lrv) + inputs.lrv;
    
    setSingleResult({
      percentage: percentage.toFixed(2),
      value: value.toFixed(2),
      unit: inputs.unit,
      type: 'signal'
    });
  };

  const calculateFromUnit = (unitValue: number) => {
    const percentage = ((unitValue - inputs.lrv) / (inputs.urv - inputs.lrv)) * 100;
    const signalValue = ((unitValue - inputs.lrv) / (inputs.urv - inputs.lrv)) * (inputs.span - inputs.zero) + inputs.zero;
    
    setSingleResult({
      percentage: percentage.toFixed(2),
      signalValue: signalValue.toFixed(2),
      signalUnit: inputs.signalUnit,
      type: 'unit'
    });
  };

  const calculateFromPercentage = (percentage: number) => {
    const unitValue = (percentage / 100) * (inputs.urv - inputs.lrv) + inputs.lrv;
    const signalValue = (percentage / 100) * (inputs.span - inputs.zero) + inputs.zero;
    
    setSingleResult({
      unitValue: unitValue.toFixed(2),
      unit: inputs.unit,
      signalValue: signalValue.toFixed(2),
      signalUnit: inputs.signalUnit,
      type: 'percentage'
    });
  };

  const calculateSqrt = (signalValue: number) => {
    const sqrtValue = Math.sqrt((signalValue - inputs.zero) / (inputs.span - inputs.zero)) * (inputs.span - inputs.zero) + inputs.zero;
    const percentage = ((sqrtValue - inputs.zero) / (inputs.span - inputs.zero)) * 100;
    
    setSingleResult({
      percentage: percentage.toFixed(2),
      sqrtValue: sqrtValue.toFixed(2),
      signalUnit: inputs.signalUnit,
      type: 'sqrt'
    });
  };

  const calculateFlowrate = (flowrate: number) => {
    const sigsqrt = ((flowrate - flowrateInputs.min) / (flowrateInputs.max - flowrateInputs.min)) * (inputs.span - inputs.zero) + inputs.zero;
    const percentage = ((sigsqrt - inputs.zero) / (inputs.span - inputs.zero)) * 100;
    const siglin = (Math.pow((sigsqrt - inputs.zero), 2) / (inputs.span - inputs.zero)) + inputs.zero;
    const press = ((siglin - inputs.zero) / (inputs.span - inputs.zero)) * (inputs.urv - inputs.lrv) + inputs.lrv;

    setSingleResult({
      percentage: percentage.toFixed(2),
      sigsqrt: sigsqrt.toFixed(2),
      signalUnit: inputs.signalUnit,
      pressure: press.toFixed(2),
      unit: inputs.unit,
      siglin: siglin.toFixed(2),
      type: 'flowrate'
    });
  };

  const calculateFromPressure = (pressure: number) => {
    const percentage = ((pressure - inputs.lrv) / (inputs.urv - inputs.lrv)) * 100;
    const siglin = ((pressure - inputs.lrv) / (inputs.urv - inputs.lrv)) * (inputs.span - inputs.zero) + inputs.zero;
    const sigsqrt = Math.sqrt((siglin - inputs.zero) / (inputs.span - inputs.zero)) * (inputs.span - inputs.zero) + inputs.zero;
    const flowrate = ((sigsqrt - inputs.zero) / (inputs.span - inputs.zero)) * (flowrateInputs.max - flowrateInputs.min) + flowrateInputs.min;

    setSingleResult({
      percentage: percentage.toFixed(2),
      siglin: siglin.toFixed(2),
      signalUnit: inputs.signalUnit,
      flowrate: flowrate.toFixed(2),
      frunit: flowrateInputs.frunit,
      sigsqrt: sigsqrt.toFixed(2),
      type: 'pressure'
    });
  };

  const InputField = ({ label, value, onChange, type = "number", placeholder }: any) => (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-300">{label}</label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-200"
      />
    </div>
  );

  const CalculationCard = ({ title, icon: Icon, children }: any) => (
    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 hover:border-gray-600 transition-all duration-200">
      <div className="flex items-center gap-3 mb-4">
        <Icon className="w-6 h-6 text-blue-400" />
        <h3 className="text-lg font-semibold text-white">{title}</h3>
      </div>
      {children}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <CalcIcon className="w-10 h-10 text-blue-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Scale Calculator Pro
            </h1>
          </div>
          <p className="text-gray-400 text-lg">Professional instrumentation calculation tool</p>
        </div>

        {/* Configuration Panel */}
        <div className="bg-gray-800 rounded-xl p-6 mb-8 border border-gray-700">
          <div className="flex items-center gap-3 mb-6">
            <Settings className="w-6 h-6 text-green-400" />
            <h2 className="text-xl font-semibold">Configuration</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <InputField
              label="LRV (Lower Range Value)"
              value={inputs.lrv}
              onChange={(e: any) => setInputs({...inputs, lrv: parseFloat(e.target.value) || 0})}
              placeholder="Enter LRV"
            />
            <InputField
              label="URV (Upper Range Value)"
              value={inputs.urv}
              onChange={(e: any) => setInputs({...inputs, urv: parseFloat(e.target.value) || 0})}
              placeholder="Enter URV"
            />
            <InputField
              label="Unit"
              value={inputs.unit}
              onChange={(e: any) => setInputs({...inputs, unit: e.target.value})}
              type="text"
              placeholder="e.g., bar, psi"
            />
            <InputField
              label="Signal Zero"
              value={inputs.zero}
              onChange={(e: any) => setInputs({...inputs, zero: parseFloat(e.target.value) || 0})}
              placeholder="Enter signal zero"
            />
            <InputField
              label="Signal Span"
              value={inputs.span}
              onChange={(e: any) => setInputs({...inputs, span: parseFloat(e.target.value) || 0})}
              placeholder="Enter signal span"
            />
            <InputField
              label="Signal Unit"
              value={inputs.signalUnit}
              onChange={(e: any) => setInputs({...inputs, signalUnit: e.target.value})}
              type="text"
              placeholder="e.g., mA, V"
            />
          </div>

          <div className="mt-6 pt-6 border-t border-gray-700">
            <h3 className="text-lg font-semibold mb-4 text-green-400">Flowrate Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <InputField
                label="Min Flowrate"
                value={flowrateInputs.min}
                onChange={(e: any) => setFlowrateInputs({...flowrateInputs, min: parseFloat(e.target.value) || 0})}
                placeholder="Enter min flowrate"
              />
              <InputField
                label="Max Flowrate"
                value={flowrateInputs.max}
                onChange={(e: any) => setFlowrateInputs({...flowrateInputs, max: parseFloat(e.target.value) || 0})}
                placeholder="Enter max flowrate"
              />
              <InputField
                label="Flowrate Unit"
                value={flowrateInputs.frunit}
                onChange={(e: any) => setFlowrateInputs({...flowrateInputs, frunit: e.target.value})}
                type="text"
                placeholder="e.g., L/min, m³/h"
              />
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 mb-8">
          {[
            { id: 'scale', label: 'Scale Calculator', icon: BarChart3 },
            { id: 'conversions', label: 'Conversions', icon: TrendingUp },
            { id: 'flowrate', label: 'Flowrate', icon: Zap }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content based on active tab */}
        {activeTab === 'scale' && (
          <div className="space-y-8">
            <CalculationCard title="Scale Calculation" icon={BarChart3}>
              <button
                onClick={calculateScaleValues}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200"
              >
                Calculate Scale Values
              </button>
              
              {results.length > 0 && (
                <div className="mt-6 overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-700">
                        <th className="border border-gray-600 px-4 py-3 text-left">Percentage</th>
                        <th className="border border-gray-600 px-4 py-3 text-left">Value</th>
                        <th className="border border-gray-600 px-4 py-3 text-left">Unit</th>
                        <th className="border border-gray-600 px-4 py-3 text-left">Signal Value</th>
                        <th className="border border-gray-600 px-4 py-3 text-left">Signal Unit</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.map((result, index) => (
                        <tr key={index} className="hover:bg-gray-700">
                          <td className="border border-gray-600 px-4 py-3">{result.percentage}%</td>
                          <td className="border border-gray-600 px-4 py-3">{result.value}</td>
                          <td className="border border-gray-600 px-4 py-3">{result.unit}</td>
                          <td className="border border-gray-600 px-4 py-3">{result.signalValue}</td>
                          <td className="border border-gray-600 px-4 py-3">{result.signalUnit}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CalculationCard>
          </div>
        )}

        {activeTab === 'conversions' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <CalculationCard title="Signal to Value" icon={TrendingUp}>
              <div className="space-y-4">
                <InputField
                  label="Signal Value"
                  value=""
                  onChange={(e: any) => calculateFromSignal(parseFloat(e.target.value) || 0)}
                  placeholder="Enter signal value"
                />
                {singleResult?.type === 'signal' && (
                  <div className="bg-gray-700 p-4 rounded-lg">
                    <p><strong>Percentage:</strong> {singleResult.percentage}%</p>
                    <p><strong>Value:</strong> {singleResult.value} {singleResult.unit}</p>
                  </div>
                )}
              </div>
            </CalculationCard>

            <CalculationCard title="Unit Value to Signal" icon={TrendingUp}>
              <div className="space-y-4">
                <InputField
                  label="Unit Value"
                  value=""
                  onChange={(e: any) => calculateFromUnit(parseFloat(e.target.value) || 0)}
                  placeholder="Enter unit value"
                />
                {singleResult?.type === 'unit' && (
                  <div className="bg-gray-700 p-4 rounded-lg">
                    <p><strong>Percentage:</strong> {singleResult.percentage}%</p>
                    <p><strong>Signal Value:</strong> {singleResult.signalValue} {singleResult.signalUnit}</p>
                  </div>
                )}
              </div>
            </CalculationCard>

            <CalculationCard title="Percentage to Values" icon={TrendingUp}>
              <div className="space-y-4">
                <InputField
                  label="Percentage"
                  value=""
                  onChange={(e: any) => calculateFromPercentage(parseFloat(e.target.value) || 0)}
                  placeholder="Enter percentage"
                />
                {singleResult?.type === 'percentage' && (
                  <div className="bg-gray-700 p-4 rounded-lg">
                    <p><strong>Unit Value:</strong> {singleResult.unitValue} {singleResult.unit}</p>
                    <p><strong>Signal Value:</strong> {singleResult.signalValue} {singleResult.signalUnit}</p>
                  </div>
                )}
              </div>
            </CalculationCard>

            <CalculationCard title="Convert Signal to SQRT" icon={TrendingUp}>
              <div className="space-y-4">
                <InputField
                  label="Signal Value"
                  value=""
                  onChange={(e: any) => calculateSqrt(parseFloat(e.target.value) || 0)}
                  placeholder="Enter signal value"
                />
                {singleResult?.type === 'sqrt' && (
                  <div className="bg-gray-700 p-4 rounded-lg">
                    <p><strong>Percentage SQRT:</strong> {singleResult.percentage}%</p>
                    <p><strong>SQRT Signal:</strong> {singleResult.sqrtValue} {singleResult.signalUnit}</p>
                  </div>
                )}
              </div>
            </CalculationCard>
          </div>
        )}

        {activeTab === 'flowrate' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <CalculationCard title="Flowrate to Signals" icon={Zap}>
              <div className="space-y-4">
                <InputField
                  label="Flowrate"
                  value=""
                  onChange={(e: any) => calculateFlowrate(parseFloat(e.target.value) || 0)}
                  placeholder="Enter flowrate"
                />
                {singleResult?.type === 'flowrate' && (
                  <div className="bg-gray-700 p-4 rounded-lg space-y-2">
                    <p><strong>Percentage SQRT:</strong> {singleResult.percentage}%</p>
                    <p><strong>Signal SQRT:</strong> {singleResult.sigsqrt} {singleResult.signalUnit}</p>
                    <p><strong>Pressure:</strong> {singleResult.pressure} {singleResult.unit}</p>
                    <p><strong>Signal Linear:</strong> {singleResult.siglin} {singleResult.signalUnit}</p>
                  </div>
                )}
              </div>
            </CalculationCard>

            <CalculationCard title="Pressure to Flowrate" icon={Zap}>
              <div className="space-y-4">
                <InputField
                  label="Pressure"
                  value=""
                  onChange={(e: any) => calculateFromPressure(parseFloat(e.target.value) || 0)}
                  placeholder="Enter pressure value"
                />
                {singleResult?.type === 'pressure' && (
                  <div className="bg-gray-700 p-4 rounded-lg space-y-2">
                    <p><strong>Percentage:</strong> {singleResult.percentage}%</p>
                    <p><strong>Signal Linear:</strong> {singleResult.siglin} {singleResult.signalUnit}</p>
                    <p><strong>Flowrate:</strong> {singleResult.flowrate} {singleResult.frunit}</p>
                    <p><strong>Signal SQRT:</strong> {singleResult.sigsqrt} {singleResult.signalUnit}</p>
                  </div>
                )}
              </div>
            </CalculationCard>
          </div>
        )}
      </div>
    </div>
  );
};

export default Calculator;